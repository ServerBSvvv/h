from Utils.Writer import Writer
from Database.DatabaseManager import DataBase


class BattleResultRoboWarsMessage(Writer):

    def __init__(self, client, player):
        super().__init__(client)
        self.id = 23456
        self.player = player

    def encode(self):
        self.writeVint(0)
        self.writeVint(self.player.battle_result)

        brawler_trophies = self.player.brawlers_trophies[str(self.player.brawler_id)]
        brawler_trophies_for_rank = self.player.brawlers_trophies_in_rank[str(self.player.brawler_id)]
        brawler_level = self.player.Brawler_level[str(self.player.brawler_id)] + 1
        exp_reward = [16, 12, 8]
        token_list = [40,30,20]
        practice_exp_reward = [8, 6, 4] 
        practice_token_list = [20,15,10]
        mvp_exp_reward = [20, 10]
        
        
        if self.player.battle_result == 0:
            result = self.player.result + 1
            starplayer = 5
        if self.player.battle_result == 1:
            result = self.player.result
            starplayer = 1
        if self.player.battle_result == 2:
            result = self.player.result
            starplayer = 5
            
        if starplayer == 5:
            starplayerexperience = mvp_exp_reward[0]
            practice_starplayerexperience = mvp_exp_reward[1]
        else:
            starplayerexperience = 0
            practice_starplayerexperience = 0
                    

        if 0 <= brawler_trophies <= 29:
            win_val = 12
            lose_val = 0
            lose_val2 = 0

        else:
            if 30 <= brawler_trophies <= 59:
                win_val = 12
                lose_val = -2
                lose_val2 = -63

            if 60 <= brawler_trophies <= 99:
                win_val = 12
                lose_val = -4
                lose_val2 = -61

            if 100 <= brawler_trophies <= 139:
                win_val = 10
                lose_val = -4
                lose_val2 = -61

            if 140 <= brawler_trophies <= 219:
                win_val = 10
                lose_val = -6
                lose_val2 = -59

            if 220 <= brawler_trophies <= 299:
                win_val = 10
                lose_val = -8
                lose_val2 = -57

            if 300 <= brawler_trophies <= 499:
                win_val = 10
                lose_val = -10
                lose_val2 = -55

            if 500 <= brawler_trophies <= 599:
                win_val = 10
                lose_val = -12
                lose_val2 = -53

            if 600 <= brawler_trophies <= 699:
                win_val = 8
                lose_val = -12
                lose_val2 = -53

            if 700 <= brawler_trophies <= 799:
                win_val = 6
                lose_val = -12
                lose_val2 = -53

            if 800 <= brawler_trophies <= 899:
                win_val = 6
                lose_val = -14
                lose_val2 = -51

            if brawler_trophies >= 900:
                win_val = 4
                lose_val = -14
                lose_val2 = -51

        if self.player.battle_result == 0:
            trophiesinresult = win_val
            if result == 0:
                trophies = 0
                mvpexperience = practice_starplayerexperience
                experience = practice_exp_reward[0]
                tokens = practice_token_list[0]
                startoken = 0
            if result == 1:
                trophies = 0
                mvpexperience = practice_starplayerexperience
                experience = practice_exp_reward[0]
                tokens = practice_token_list[0]
                startoken = 1
            if result == 2:
                trophies = 0
                mvpexperience = 0
                experience = 0
                tokens = practice_token_list[0]
                startoken = 0
            if result == 3:
                trophies = 0
                mvpexperience = 0
                experience = 0
                tokens = practice_token_list[0]
                startoken = 1
            if result == 4:
                trophies = 0
                mvpexperience = practice_starplayerexperience
                experience = practice_exp_reward[0]
                tokens = 0
                startoken = 0
            if result == 5:
                trophies = 0
                mvpexperience = practice_starplayerexperience
                experience = practice_exp_reward[0]
                tokens = 0
                startoken = 1
            if result == 6:
                trophies = 0
                mvpexperience = 0
                experience = 0
                tokens = 0
                startoken = 0
            if result == 7:
                trophies = 0
                mvpexperience = 0
                experience = 0
                tokens = 0
                startoken = 1
            if result == 8:
                trophies = 0
                mvpexperience = practice_starplayerexperience
                experience = practice_exp_reward[0]
                tokens = practice_token_list[0]
                startoken = 0
            if result == 9:
                trophies = 0
                mvpexperience = practice_starplayerexperience
                experience = practice_exp_reward[0]
                tokens = practice_token_list[0]
                startoken = 1
            if result == 10:
                trophies = 0
                mvpexperience = 0
                experience = 0
                tokens = practice_token_list[0]
                startoken = 0
            if result == 11:
                trophies = 0
                mvpexperience = 0
                experience = 0
                tokens = practice_token_list[0]
                startoken = 1
            if result == 12:
                trophies = 0
                mvpexperience = practice_starplayerexperience
                experience = practice_exp_reward[0]
                tokens = 0
                startoken = 0
            if result == 13:
                trophies = 0
                mvpexperience = practice_starplayerexperience
                experience = practice_exp_reward[0]
                tokens = 0
                startoken = 1
            if result == 14:
                trophies = 0
                mvpexperience = 0
                experience = 0
                tokens = 0
                startoken = 0
            if result == 15:
                trophies = 0
                mvpexperience = 0
                experience = 0
                tokens = 0
                startoken = 1
            if result == 16:
                trophies = win_val
                mvpexperience = starplayerexperience
                experience = exp_reward[0]
                tokens = token_list[0]
                startoken = 0
            if result == 17:
                trophies = win_val
                mvpexperience = starplayerexperience
                experience = exp_reward[0]
                tokens = token_list[0]
                startoken = 1
            if result == 18:
                trophies = win_val
                mvpexperience = 0
                experience = 0
                tokens = token_list[0]
                startoken = 0
            if result == 19:
                trophies = win_val
                mvpexperience = 0
                experience = 0
                tokens = token_list[0]
                startoken = 1
            if result == 20:
                trophies = win_val
                mvpexperience = starplayerexperience
                experience = exp_reward[0]
                tokens = 0
                startoken = 0
            if result == 21:
                trophies = win_val
                mvpexperience = starplayerexperience
                experience = exp_reward[0]
                tokens = 0
                startoken = 1
            if result == 22:
                trophies = win_val
                mvpexperience = 0
                experience = 0
                tokens = 0
                startoken = 0
            if result == 23:
                trophies = win_val
                mvpexperience = 0
                experience = 0
                tokens = 0
                startoken = 1
            if result == 24:
                trophies = win_val
                mvpexperience = starplayerexperience
                experience = exp_reward[0]
                tokens = token_list[0]
                startoken = 0
            if result == 25:
                trophies = win_val
                mvpexperience = starplayerexperience
                experience = exp_reward[0]
                tokens = token_list[0]
                startoken = 1
            if result == 26:
                trophies = win_val
                mvpexperience = 0
                experience = 0
                tokens = token_list[0]
                startoken = 0
            if result == 27:
                trophies = win_val
                mvpexperience = 0
                experience = 0
                tokens = token_list[0]
                startoken = 1
            if result == 28:
                trophies = win_val
                mvpexperience = starplayerexperience
                experience = exp_reward[0]
                tokens = 0
                startoken = 0
            if result == 29:
                trophies = win_val
                mvpexperience = starplayerexperience
                experience = exp_reward[0]
                tokens = 0
                startoken = 1
            if result == 30:
                trophies = win_val
                mvpexperience = 0
                experience = 0
                tokens = 0
                startoken = 0
            if result == 31:
                trophies = win_val
                mvpexperience = 0
                experience = 0
                tokens = 0
                startoken = 1
                
            self.player.ThreeVSThree_wins += 1
            self.player.player_experience += experience + mvpexperience
            if self.player.tokensdoubler <= 0:
                doubledtokens = 0
            if self.player.tokensdoubler > tokens:
                doubledtokens = tokens
            if tokens > self.player.tokensdoubler: 
                doubledtokens = self.player.tokensdoubler
            remainingtokens = (self.player.tokensdoubler) - doubledtokens
            totaltokens = tokens + doubledtokens
            new_trophies = self.player.trophies + trophies
            new_tokens = self.player.brawl_boxes + totaltokens
            new_startokens = self.player.big_boxes + startoken
            self.player.brawlers_trophies[str(self.player.brawler_id)] = brawler_trophies + trophies
            if self.player.brawlers_trophies_in_rank[str(self.player.brawler_id)] < self.player.brawlers_trophies[str(self.player.brawler_id)]:
                self.player.brawlers_trophies_in_rank[str(self.player.brawler_id)] = brawler_trophies_for_rank + trophies
            DataBase.replaceValue(self, 'brawlersTrophies', self.player.brawlers_trophies)
            DataBase.replaceValue(self, 'brawlersTrophiesForRank', self.player.brawlers_trophies_in_rank)
            DataBase.replaceValue(self, 'brawlersTrophiesForRank', self.player.brawlers_trophies_in_rank)
            DataBase.replaceValue(self, 'trophies', new_trophies)
            DataBase.replaceValue(self, 'brawlBoxes', new_tokens)
            DataBase.replaceValue(self, 'bigBoxes', new_startokens)
            DataBase.replaceValue(self, 'tokensdoubler', remainingtokens)
            DataBase.replaceValue(self, 'playerExp', self.player.player_experience)
            DataBase.replaceValue(self, '3vs3Wins', self.player.ThreeVSThree_wins)
            
        elif self.player.battle_result == 1:
            trophiesinresult = lose_val2
            startoken = 0
            if result == 0:
                trophies = 0
                mvpexperience = practice_starplayerexperience
                experience = practice_exp_reward[2]
                tokens = practice_token_list[2]
            if result == 1:
                trophies = 0
                mvpexperience = practice_starplayerexperience
                experience = practice_exp_reward[2]
                tokens = practice_token_list[2]
            if result == 2:
                trophies = 0
                mvpexperience = 0
                experience = 0
                tokens = practice_token_list[2]
            if result == 3:
                trophies = 0
                mvpexperience = 0
                experience = 0
                tokens = practice_token_list[2]
            if result == 4:
                trophies = 0
                mvpexperience = practice_starplayerexperience
                experience = practice_exp_reward[2]
                tokens = 0
            if result == 5:
                trophies = 0
                mvpexperience = practice_starplayerexperience
                experience = practice_exp_reward[2]
                tokens = 0
            if result == 6:
                trophies = 0
                mvpexperience = 0
                experience = 0
                tokens = 0
            if result == 7:
                trophies = 0
                mvpexperience = 0
                experience = 0
                tokens = 0
            if result == 8:
                trophies = 0
                mvpexperience = practice_starplayerexperience
                experience = practice_exp_reward[2]
                tokens = practice_token_list[2]
            if result == 9:
                trophies = 0
                mvpexperience = practice_starplayerexperience
                experience = practice_exp_reward[2]
                tokens = practice_token_list[2]
            if result == 10:
                trophies = 0
                mvpexperience = 0
                experience = 0
                tokens = practice_token_list[2]
            if result == 11:
                trophies = 0
                mvpexperience = 0
                experience = 0
                tokens = practice_token_list[2]
            if result == 12:
                trophies = 0
                mvpexperience = practice_starplayerexperience
                experience = practice_exp_reward[2]
                tokens = 0
            if result == 13:
                trophies = 0
                mvpexperience = practice_starplayerexperience
                experience = practice_exp_reward[2]
                tokens = 0
            if result == 14:
                trophies = 0
                mvpexperience = 0
                experience = 0
                tokens = 0
            if result == 15:
                trophies = 0
                mvpexperience = 0
                experience = 0
                tokens = 0
            if result == 16:
                trophies = lose_val
                mvpexperience = starplayerexperience
                experience = exp_reward[2]
                tokens = token_list[2]
            if result == 17:
                trophies = lose_val
                mvpexperience = starplayerexperience
                experience = exp_reward[2]
                tokens = token_list[2]
            if result == 18:
                trophies = lose_val
                mvpexperience = 0
                experience = 0
                tokens = token_list[2]
            if result == 19:
                trophies = lose_val
                mvpexperience = 0
                experience = 0
                tokens = token_list[2]
            if result == 20:
                trophies = lose_val
                mvpexperience = starplayerexperience
                experience = exp_reward[2]
                tokens = 0
            if result == 21:
                trophies = lose_val
                mvpexperience = starplayerexperience
                experience = exp_reward[2]
                tokens = 0
            if result == 22:
                trophies = lose_val
                mvpexperience = starplayerexperience
                experience = 0
                tokens = 0
            if result == 23:
                trophies = lose_val
                mvpexperience = 0
                experience = 0
                tokens = 0
            if result == 24:
                trophies = lose_val
                mvpexperience = starplayerexperience
                experience = exp_reward[2]
                tokens = token_list[2]
            if result == 25:
                trophies = lose_val
                mvpexperience = starplayerexperience
                experience = exp_reward[2]
                tokens = token_list[2]
            if result == 26:
                trophies = lose_val
                mvpexperience = 0
                experience = 0
                tokens = token_list[2]
            if result == 27:
                trophies = lose_val
                mvpexperience = 0
                experience = 0
                tokens = token_list[2]
            if result == 28:
                trophies = lose_val
                mvpexperience = starplayerexperience
                experience = exp_reward[2]
                tokens = 0
            if result == 29:
                trophies = lose_val
                mvpexperience = starplayerexperience
                experience = exp_reward[2]
                tokens = 0
            if result == 30:
                trophies = lose_val
                mvpexperience = 0
                experience = 0
                tokens = 0
            if result == 31:
                trophies = lose_val
                mvpexperience = 0
                experience = 0
                tokens = 0
                
            self.player.player_experience += experience + mvpexperience
            if self.player.tokensdoubler <= 0:
                doubledtokens = 0
            if self.player.tokensdoubler > tokens:
                doubledtokens = tokens
            if tokens > self.player.tokensdoubler: 
                doubledtokens = self.player.tokensdoubler
            remainingtokens = (self.player.tokensdoubler) - doubledtokens
            totaltokens = tokens + doubledtokens
            new_trophies = self.player.trophies + trophies
            new_tokens = self.player.brawl_boxes + totaltokens
            self.player.brawlers_trophies[str(self.player.brawler_id)] = brawler_trophies + trophies
            DataBase.replaceValue(self, 'brawlersTrophies', self.player.brawlers_trophies)
            DataBase.replaceValue(self, 'brawlersTrophiesForRank', self.player.brawlers_trophies_in_rank)
            DataBase.replaceValue(self, 'trophies', new_trophies)
            DataBase.replaceValue(self, 'brawlBoxes', new_tokens)
            DataBase.replaceValue(self, 'tokensdoubler', remainingtokens)
            DataBase.replaceValue(self, 'playerExp', self.player.player_experience)

        elif self.player.battle_result == 2:
            trophiesinresult = 0
            trophies = 0
            startoken = 0
            if result == 0:
                mvpexperience = practice_starplayerexperience
                experience = practice_exp_reward[1]
                tokens = practice_token_list[1]
            if result == 1:
                mvpexperience = practice_starplayerexperience
                experience = practice_exp_reward[1]
                tokens = practice_token_list[1]
            if result == 2:
                mvpexperience = 0
                experience = 0
                tokens = practice_token_list[1]
            if result == 3:
                mvpexperience = 0
                experience = 0
                tokens = practice_token_list[1]
            if result == 4:
                mvpexperience = practice_starplayerexperience
                experience = practice_exp_reward[1]
                tokens = 0
            if result == 5:
                mvpexperience = practice_starplayerexperience
                experience = practice_exp_reward[1]
                tokens = 0
            if result == 6:
                mvpexperience = 0
                experience = 0
                tokens = 0
            if result == 7:
                mvpexperience = 0
                experience = 0
                tokens = 0
            if result == 8:
                mvpexperience = practice_starplayerexperience
                experience = practice_exp_reward[1]
                tokens = practice_token_list[1]
            if result == 9:
                mvpexperience = practice_starplayerexperience
                experience = practice_exp_reward[1]
                tokens = practice_token_list[1]
            if result == 10:
                mvpexperience = 0
                experience = 0
                tokens = practice_token_list[1]
            if result == 11:
                mvpexperience = 0
                experience = 0
                tokens = practice_token_list[1]
            if result == 12:
                mvpexperience = practice_starplayerexperience
                experience = practice_exp_reward[1]
                tokens = 0
            if result == 13:
                mvpexperience = practice_starplayerexperience
                experience = practice_exp_reward[1]
                tokens = 0
            if result == 14:
                mvpexperience = 0
                experience = 0
                tokens = 0
            if result == 15:
                mvpexperience = 0
                experience = 0
                tokens = 0
            if result == 16:
                mvpexperience = starplayerexperience
                experience = exp_reward[1]
                tokens = token_list[1]
            if result == 17:
                mvpexperience = starplayerexperience
                experience = exp_reward[1]
                tokens = token_list[1]
            if result == 18:
                mvpexperience = 0
                experience = 0
                tokens = token_list[1]
            if result == 19:
                mvpexperience = 0
                experience = 0
                tokens = token_list[1]
            if result == 20:
                mvpexperience = starplayerexperience
                experience = exp_reward[1]
                tokens = 0
            if result == 21:
                mvpexperience = starplayerexperience
                experience = exp_reward[1]
                tokens = 0
            if result == 22:
                mvpexperience = 0
                experience = 0
                tokens = 0
            if result == 23:
                mvpexperience = 0
                experience = 0
                tokens = 0
            if result == 24:
                mvpexperience = starplayerexperience
                experience = exp_reward[1]
                tokens = token_list[1]
            if result == 25:
                mvpexperience = starplayerexperience
                experience = exp_reward[1]
                tokens = token_list[1]
            if result == 26:
                mvpexperience = 0
                experience = 0
                tokens = token_list[1]
            if result == 27:
                mvpexperience = 0
                experience = 0
                tokens = token_list[1]
            if result == 28:
                mvpexperience = starplayerexperience
                experience = exp_reward[1]
                tokens = 0
            if result == 29:
                mvpexperience = starplayerexperience
                experience = exp_reward[1]
                tokens = 0
            if result == 30:
                mvpexperience = 0
                experience = 0
                tokens = 0
            if result == 31:
                mvpexperience = 0
                experience = 0
                tokens = 0
                
            self.player.player_experience += experience + mvpexperience
            if self.player.tokensdoubler <= 0:
                doubledtokens = 0
            if self.player.tokensdoubler > tokens:
                doubledtokens = tokens
            if tokens > self.player.tokensdoubler: 
                doubledtokens = self.player.tokensdoubler
            remainingtokens = (self.player.tokensdoubler) - doubledtokens
            totaltokens = tokens + doubledtokens
            new_tokens = self.player.brawl_boxes + totaltokens
            DataBase.replaceValue(self, 'brawlBoxes', new_tokens)
            DataBase.replaceValue(self, 'tokensdoubler', remainingtokens)
            DataBase.replaceValue(self, 'playerExp', self.player.player_experience)

        self.writeVint(tokens) # Tokens Gained
        self.writeVint(trophiesinresult) # Trophies Result
        self.writeVint(doubledtokens) # Doubled Tokens
        self.writeVint(remainingtokens) # Token Doubler Remaining
        self.writeVint(0) # Big Game/Robo Rumble Time
        self.writeVint(result) # Battle Result Info and Stuff
        self.writeVint(6) #Battle End Screen Players

        self.writeString(self.player.name) # Player Name
        self.writeVint(starplayer) # Self Star Player Type
        self.writeVint(16) # Brawler CsvID
        self.writeVint(self.player.brawler_id) # Brawler
        self.writeVint(29) # Skin CsvID
        self.writeVint(self.player.skin_id) # Brawler Skin
        self.writeVint(brawler_trophies) # Brawler Trophies
        self.writeVint(10) # Brawler Power Level
        bool = True
        self.writeBoolean(bool)
        if bool == True:
            self.writeInt(self.player.high_id) # HighID
            self.writeInt(self.player.low_id) # LowID
        
        self.writeString('Bot 1') # Bot 1 Name
        self.writeVint(0) # Star Player Type
        self.writeVint(16) # Brawler CsvID
        self.writeVint(self.player.bot1) # Bot 1
        self.writeVint(0) # Skin CsvID
        self.writeVint(0) # Brawler Trophies
        self.writeVint(10) # Brawler Power Level
        bool = True
        self.writeBoolean(bool)
        if bool == True:
            self.writeInt(0) # HighID
            self.writeInt(2) # LowID
            
        self.writeString('Bot 2') # Bot 2 Name
        self.writeVint(0) # Star Player Type
        self.writeVint(16) # Brawler CsvID
        self.writeVint(self.player.bot2) # Bot 2
        self.writeVint(0) # Skin CsvID
        self.writeVint(0) # Brawler Trophies
        self.writeVint(10) # Brawler Power Level
        bool = True
        self.writeBoolean(bool)
        if bool == True:
            self.writeInt(0) # HighID
            self.writeInt(3) # LowID

        self.writeString('Bot 3') # Bot 3 Name
        self.writeVint(2) # Enemy Star Player Type
        self.writeVint(16) # Brawler CsvID
        self.writeVint(self.player.bot3) # Bot 3
        self.writeVint(0) # Skin CsvID
        self.writeVint(0) # Brawler Trophies
        self.writeVint(10) # Brawler Power Level
        bool = True
        self.writeBoolean(bool)
        if bool == True:
            self.writeInt(0) # HighID
            self.writeInt(2) # LowID

        self.writeString('Bot 4') # Bot 4 Name
        self.writeVint(2) # Enemy Star Player Type
        self.writeVint(16) # Brawler CsvID
        self.writeVint(self.player.bot4) # Bot 4
        self.writeVint(0) # Skin CsvID
        self.writeVint(0) # Brawler Trophies
        self.writeVint(10) # Brawler Power Level
        bool = True
        self.writeBoolean(bool)
        if bool == True:
            self.writeInt(0) # HighID
            self.writeInt(1) # LowID

        self.writeString('Bot 5') # Bot 5 Name
        self.writeVint(2) # Enemy Star Player Type
        self.writeVint(16) # Brawler CsvID
        self.writeVint(self.player.bot5) # Bot 5
        self.writeVint(0) # Skin CsvID
        self.writeVint(0) # Brawler Trophies
        self.writeVint(10) # Brawler Power Level
        bool = True
        self.writeBoolean(bool)
        if bool == True:
            self.writeInt(0) # HighID
            self.writeInt(1) # LowID

        # Experience Array
        self.writeVint(2) # Count
        self.writeVint(0) # Normal Experience ID
        self.writeVint(experience) # Normal Experience Ammount
        self.writeVint(8) # Star Player Experience ID
        self.writeVint(mvpexperience) # Star Player Experience Ammount

        # Rank Up and Level Up Bonus Array
        self.writeVint(0) # Count

        # Trophies and Experience Bars Array
        self.writeVint(2) # Count
        self.writeVint(1) # Ranks Milestone ID
        self.writeVint(brawler_trophies) # Brawler Trophies Bar
        self.writeVint(brawler_trophies_for_rank) # Brawler Trophies for Rank
        self.writeVint(5) # Experience Milestone ID
        self.writeVint(self.player.player_experience -experience -mvpexperience) # Total Experience Bar
        self.writeVint(self.player.player_experience -experience -mvpexperience) # ???
        
        self.writeVint(0)
        self.writeBoolean(True)